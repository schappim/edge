# Edge is an awesome home automation tool made at the Raspberry Pi Workshop
